/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sharpmacro;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Alessandro
 */
public class SharpMacro extends JFrame implements ActionListener{
    final int heigth=300;
    final int width=500;
    JComboBox creaMacro;
    JLabel descrizione;
    JPanel pannello;
    JTable listaM;
    JButton record;
    
    SharpMacro(){
        
        
        pannello= new JPanel(new GridBagLayout());
        GridBagConstraints c= new GridBagConstraints();
        descrizione= new JLabel("Prova descrizione");
        String [] opzioni= {"Registra mouse", "Registra tastera", "Registra Mouse e Tastiera"};
        creaMacro= new JComboBox(opzioni);
        String[] cN={"Nome", "Data", "HotKey"};
        String[][] dati={{"","",""}, {"","",""}};
        listaM= new JTable(dati, cN) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        listaM.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane tabellaM = new JScrollPane(listaM);
        tabellaM.setPreferredSize(new Dimension(width, heigth/2));
        
        record=new JButton("Record Macro");
        record.addActionListener(this);
        
        c.weightx = c.weighty = 0.5;
        c.gridx = c.gridy = 0;
        c.anchor = GridBagConstraints.LINE_START;
        pannello.add(creaMacro, c);
        c.insets = new Insets(30,0,0,0);
        c.gridy++;
        pannello.add(descrizione, c);
        c.gridy++;
        pannello.add(tabellaM, c);
        c.gridy++;
        c.anchor = GridBagConstraints.LAST_LINE_END;
        c.insets = new Insets(30,30,30,30);
        pannello.add(record, c);
        
        TitledBorder title = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black),"Home");
        title.setTitleJustification(TitledBorder.LEFT);
        pannello.setBorder(title);
        
        setTitle("SharpMacro");
        setContentPane(pannello);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(width, heigth);
        setResizable(false);
        setLocation(100, 100);
        pack();
        setVisible(true);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("Click");
        if(listaM.getSelectedRow()!=-1){
            System.out.println(listaM.getSelectedRow());
        }
    }
}