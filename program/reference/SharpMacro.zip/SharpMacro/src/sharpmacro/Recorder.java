package sharpmacro;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListSelectionModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Francesco Verardo
 */
public class Recorder extends JFrame implements ActionListener{
    final int heigth=300, width=500;
    private JPanel pannello;
    private JButton play, strec, stprec, imp;
    private JTable list;
    private JScrollPane tabellaM;
    
    public Recorder(){
        GridBagConstraints c= new GridBagConstraints();
        String[][] process = {{""},{""},{""}};
        String[] jTableName = {"Active processes"};
        
        pannello = new JPanel();
        play = new JButton("Play");
        strec = new JButton("Start Recording");
        stprec = new JButton("Stop Recording");
        imp = new JButton("imposta processo");
        list = new JTable(process, jTableName) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        tabellaM = new JScrollPane(list);
        tabellaM.setPreferredSize(new Dimension(width, heigth/2));
        
        
        
        c.weightx = c.weighty = 0.5;
        c.gridx = c.gridy = 0;
        c.anchor = GridBagConstraints.LINE_START;
        c.gridy++;
        pannello.add(play, c);
        c.gridy++;
        pannello.add(strec, c);
        c.gridy++;
        pannello.add(stprec, c);
        c.gridy++;
        pannello.add(tabellaM, c);
        c.insets = new Insets(30,0,0,0);
        c.gridy++;
        c.insets = new Insets(30,30,30,30);
        c.anchor = GridBagConstraints.LAST_LINE_END;
        pannello.add(imp, c);
        
        
        
        TitledBorder title = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black),"");
        title.setTitleJustification(TitledBorder.LEFT);
        pannello.setBorder(title);
        
        setTitle("Recorder");
        setContentPane(pannello);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(width,heigth);
        setResizable(false);
        setLocation(100, 100);
        pack();
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {}
    
}