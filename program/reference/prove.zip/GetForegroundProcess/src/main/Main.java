/////*
//// * To change this license header, choose License Headers in Project Properties.
//// * To change this template file, choose Tools | Templates
//// * and open the template in the editor.
//// */
////
////package main;
////
////import java.io.BufferedReader;
////import java.io.InputStreamReader;
////
////
////public class Main {
////    public static void main(String[] args) throws Exception{
//////        EnumerateWindows f = new EnumerateWindows();
//////        f.execute();
////    
////        Runtime runtime = Runtime.getRuntime();
////        try {
////            Process process = runtime.exec("C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe \"gps | ? {$_.mainwindowtitle.length -ne 0} | select name\"");
////            BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
////            BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
////
////            // read the output from the command
////            System.out.println("Standard output of the command:\n");
////            String s = null;
////            while ((s = stdInput.readLine()) != null) {
////                System.out.println(s);
////            }
////
////            // read any errors from the attempted command
////            System.out.println("Standard error of the command (if any):\n");
////            while ((s = stdError.readLine()) != null) {
////                System.out.println(s);
////            }
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////
////    }
////}
//import com.sun.jna.Native;
//import com.sun.jna.Pointer;
//import com.sun.jna.win32.StdCallLibrary;
//import java.util.ArrayList;
//import java.util.List;
//
//public class Main {
//   static interface User32 extends StdCallLibrary {
//      User32 INSTANCE = (User32) Native.loadLibrary("user32", User32.class);
//
//      interface WNDENUMPROC extends StdCallCallback {
//         boolean callback(Pointer hWnd, Pointer arg);
//      }
//
//      boolean EnumWindows(WNDENUMPROC lpEnumFunc, Pointer userData);
//      int GetWindowTextA(Pointer hWnd, byte[] lpString, int nMaxCount);
//      Pointer GetWindow(Pointer hWnd, int uCmd);
//   }
//
//   public static List<String> getAllWindowNames() {
//      final List<String> windowNames = new ArrayList<>();
//      final User32 user32 = User32.INSTANCE;
//      user32 .EnumWindows((Pointer hWnd, Pointer arg) -> {
//          byte[] windowText = new byte[512];
//          user32.GetWindowTextA(hWnd, windowText, 512);
//          String wText = Native.toString(windowText).trim();
//          if (!wText.isEmpty()) {
//              windowNames.add(wText);
//          }
//          return true;
//      }, null);
//
//      return windowNames;
//   }
//
//   public static void main(String[] args) {
//      List<String> winNameList = getAllWindowNames();
//      winNameList.forEach(winName -> {
//          System.out.println(winName);
//       });
//   }
//
//test it in your CMD as powershell -command "get-Process cmd | format-table mainwindowtitle"
//    String listCommand = "powershell -command \"get-Process cmd | format-table mainwindowtitle\"";
//    try
//    {
//        String line;
//
//
//        // since line length for powershell output is 79
//        int outLen = 79;
//
//
//
//        Process p = Runtime.getRuntime().exec(listCommand);
//        BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
//        line = input.readLine();
//        System.out.println("line: " + line + "\t" + line.length());
//
//
//
//        EnginesListFromTaskManeger = new ArrayList<String>();
//        int i = 0;
//
//        /*
//         I used this outLen > 0 condition to make sure that this method will close automatically 
//         in case of no running CMD applications and you running this from your IDE's (Eclipse, Netbeans , ......) 
//         the powershell will not stopped so i used it. */
//        while(line != null && outLen > 0)
//        {
//            System.out.println("line: " + line + "\t" + line.length());
//
//            line = input.readLine().trim().toLowerCase();
//            outLen = line.length();
//
//            EnginesListFromTaskManeger.add(i, line);
//
//            System.out.println(EnginesListFromTaskManeger.get(i));
//            // EnginesListFromTaskManeger[i]=(String)input.readLine().trim();
//            // System.out.println("EnginesListFromTaskManeger"+ EnginesListFromTaskManeger[i]);
//            i++;
//        }
//        input.close();
//    }catch(Exception err)
//    {
//        err.printStackTrace();
//    }
//
//    ListFromTaskManeger = new String[EnginesListFromTaskManeger.size()];
//    ListFromTaskManeger = EnginesListFromTaskManeger.toArray(ListFromTaskManeger);
//
//    return ListFromTaskManeger;
//
//}
//}